class LoadingSpinner extends HTMLElement {
    connectedCallback() {
      this.innerHTML = `<div id="loadingSpinner" style="display:none;"><span>Loading...</span></div>`;
    }
  
    show() {
      this.querySelector('#loadingSpinner').style.display = 'block';
    }
  
    hide() {
      this.querySelector('#loadingSpinner').style.display = 'none';
    }
  }
  customElements.define('loading-spinner', LoadingSpinner);
  