class NoteFilter extends HTMLElement {
    connectedCallback() {
      this.innerHTML = `
        <div class="form">
          <input type="text" id="searchInput" placeholder="Cari catatan..." />
          <select id="sortOrder">
            <option value="desc">Terbaru</option>
            <option value="asc">Terlama</option>
          </select>
          <p id="noteCount">0 catatan ditemukan</p>
        </div>
      `;
  
      this.querySelector('#searchInput').addEventListener('input', () => {
        window.showNotes();
      });
      this.querySelector('#sortOrder').addEventListener('change', () => {
        window.showNotes();
      });
    }
  }
  customElements.define('note-filter', NoteFilter);
  