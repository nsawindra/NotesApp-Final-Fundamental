class NoteItem extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
      <div class="note">
        <h3>${this.getAttribute('title')}</h3>
        <p>${this.getAttribute('body')}</p>
        <small>${this.getAttribute('created')}</small>
      </div>
    `;
  }
}
customElements.define('note-item', NoteItem);