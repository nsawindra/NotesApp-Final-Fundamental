class NoteList extends HTMLElement {
  render(notes) {
    this.innerHTML = '';

    if (notes.length === 0) {
      this.innerHTML = '<p>Tidak ada catatan ditemukan.</p>';
      return;
    }

    const noteCards = notes.map(note => `
      <div class="note-card" data-id="${note.id}">
        <div>
          <strong>${note.title}</strong>
          <small>${new Date(note.createdAt).toLocaleString('id-ID')}</small>
          <p>${note.body}</p>
        </div>
        <button class="delete-button">Hapus</button>
      </div>
    `).join('');

    this.innerHTML = `
      <div class="note-list-grid">
        ${noteCards}
      </div>
    `;

    
    this.querySelectorAll('.delete-button').forEach(button => {
      button.addEventListener('click', (event) => {
        const noteCard = event.target.closest('.note-card');
        const noteId = noteCard.getAttribute('data-id');
        this.dispatchEvent(new CustomEvent('delete-note', {
          detail: { id: noteId },
          bubbles: true,
        }));
      });
    });
  }
}

customElements.define('note-list', NoteList);
