class NoteForm extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
      <div class="form">
        <input type="text" id="noteTitle" placeholder="Judul Catatan" />
        <textarea id="noteContent" placeholder="Isi Catatan"></textarea>
        <button id="saveNote">Tambah Catatan</button>
      </div>
    `;

    this.querySelector('#saveNote').addEventListener('click', () => {
      window.addNote();
    });
  }
}

customElements.define('note-form', NoteForm);
