import './components/note-form.js';
import './components/note-filter.js';
import './components/note-list.js';
import './components/loading-spinner.js';

function getLoadingSpinner() {
  return document.querySelector('loading-spinner');
}

export async function addNote() {
  const title = document.getElementById('noteTitle').value.trim();
  const body = document.getElementById('noteContent').value.trim();

  if (!title || !body) {
    alert('Mohon isi judul dan isi catatan.');
    return;
  }

  try {
    getLoadingSpinner()?.show();

    const response = await fetch('https://notes-api.dicoding.dev/v2/notes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, body }),
    });

    if (!response.ok) throw new Error('Gagal menambahkan catatan.');

   
    document.getElementById('noteTitle').value = '';
    document.getElementById('noteContent').value = '';

   
    await showNotes();

  } catch (error) {
    console.error(error);
    alert('Gagal menambahkan catatan.');
  } finally {
    getLoadingSpinner()?.hide();
  }
}

export async function showNotes() {
  const searchKeyword = document.getElementById('searchInput')?.value.toLowerCase() || '';
  const sortOrder = document.getElementById('sortOrder')?.value || 'desc';
  const noteList = document.querySelector('note-list');

  try {
    getLoadingSpinner()?.show();

    const response = await fetch('https://notes-api.dicoding.dev/v2/notes');
    const { data: allNotes } = await response.json();

    const filteredNotes = allNotes
      .filter(note =>
        note.title.toLowerCase().includes(searchKeyword) ||
        note.body.toLowerCase().includes(searchKeyword)
      )
      .sort((a, b) => {
        const timeA = new Date(a.createdAt).getTime();
        const timeB = new Date(b.createdAt).getTime();
        return sortOrder === 'asc' ? timeA - timeB : timeB - timeA;
      });

    noteList.render(filteredNotes);
    document.getElementById('noteCount').innerText = `${filteredNotes.length} catatan ditemukan`;

  } catch (error) {
    console.error('Gagal memuat catatan:', error);
    alert('Gagal memuat catatan dari API');
  } finally {
    getLoadingSpinner()?.hide();
  }
}

document.addEventListener('DOMContentLoaded', () => {
  showNotes();
});

window.addNote = addNote;
window.showNotes = showNotes;
document.querySelector('note-list').addEventListener('delete-note', async (e) => {
  const id = e.detail.id;

  if (!confirm('Apakah kamu yakin ingin menghapus catatan ini?')) {
    return;
  }

  try {
    getLoadingSpinner()?.show();

    const response = await fetch(`https://notes-api.dicoding.dev/v2/notes/${id}`, {
      method: 'DELETE',
    });

    if (!response.ok) {
      throw new Error('Gagal menghapus catatan.');
    }

   
    await showNotes();

  } catch (error) {
    console.error(error);
    alert('Gagal menghapus catatan.');
  } finally {
    getLoadingSpinner()?.hide();
  }
});

